UDHA — PRISHTINË Android demo

Bu proje, gönderdiğin çalışan HTML prototipini Android WebView içinde açar.
Orijinal HTML dosyası app/src/main/assets/index.html içine değiştirilmeden eklenmiştir.
JavaScript, localStorage ve GPS konum izni desteği açıktır.

WINDOWS 7 NOTU
Bu proje güncel Android Gradle Plugin, Java 17 ve Android SDK 35 kullanır.
Windows 7 üzerinde güncel Android Studio kurmak/çalıştırmak sorunlu olabilir.
Bu nedenle .github/workflows/android.yml ile APK'yı GitHub Actions üzerinde bulutta derleyebilirsin.

BULUTTA APK OLUŞTURMA
1. GitHub hesabınla github.com'a gir.
2. New repository seç; örneğin Udha-Prishtine adını ver.
3. Proje klasörünün içindeki TÜM dosya ve klasörleri depoya yükle (UdhaAndroid klasörünün içeriği).
4. GitHub deposunda Actions sekmesine gir.
5. Build Udha Android APK iş akışını seç ve Run workflow düğmesine bas.
6. İşlem bitince çalışmanın sayfasındaki Artifacts bölümünden Udha-Prishtine-APK dosyasını indir.
7. ZIP'i aç; app-debug.apk dosyasını Android telefona gönderip kur.

APK, Android 6.0 (API 23) ve üzerini hedefleyen debug/demo sürümüdür.
İlk kurulumda Android, bilinmeyen kaynaktan uygulama yükleme izni isteyebilir.

ÖNEMLİ
Bu paket mevcut prototipi tek cihazda çalışan demo uygulama olarak sunar.
Veriler cihazın kendi depolamasındadır. Gerçek yolcu-sürücü eşleşmesi, ayrı hesaplar,
canlı filo senkronizasyonu ve ödeme için daha sonra sunucu/API altyapısı gerekir.
